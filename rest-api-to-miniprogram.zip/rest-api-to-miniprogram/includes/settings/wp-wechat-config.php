<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function weixinapp_create_menu() {
    // 创建新的顶级菜单
    //add_menu_page('小白小程序', '小白小程序', 'administrator', 'weixinapp_slug', 'weixinapp_settings_page', REST_API_TO_MINIPROGRAM_PLUGIN_URL.'includes/images/icon16.png',null);
    add_menu_page('小白小程序', '小白小程序', 'administrator', 'weixinapp_slug', 'weixinapp_settings_page', 'none',99);
     add_submenu_page('weixinapp_slug', "基础设置", "基础设置", "administrator", 'weixinapp_slug','weixinapp_settings_page');
    // 调用注册设置函数
    add_action( 'admin_init', 'register_weixinappsettings' );
}

function get_jquery_source() {
        $url = plugins_url('',__FILE__); 
        wp_enqueue_style("tabs", plugins_url()."/rest-api-to-miniprogram/includes/js/tab/tabs.css", false, "1.0", "all");
        wp_enqueue_script("tabs", plugins_url()."/rest-api-to-miniprogram/includes/js/tab/tabs.min.js", false, "1.0");
        wp_enqueue_script('rawscript', plugins_url().'/'.REST_API_TO_MINIPROGRAM_PLUGIN_NAME.'/includes/js/script.js', false, '1.0');
        if ( function_exists( 'wp_enqueue_media' ) ) {
            wp_enqueue_media();
        }    
    }


function register_weixinappsettings() {
    // 注册设置
    register_setting( 'weixinapp-group', 'wf_appid' );
    register_setting( 'weixinapp-group', 'wf_secret' );
    // register_setting( 'weixinapp-group', 'wf_swipe' );
    
    register_setting( 'weixinapp-group', 'wf_mchid' );
	
	
	
	  register_setting( 'weixinapp-group', 'kongzhicode' );
	    register_setting( 'weixinapp-group', 'kongzhishichang' );
		  register_setting( 'weixinapp-group', 'kongzhiminsuijishu' );
		    register_setting( 'weixinapp-group', 'kongzhimaxsuijishu' );
			 register_setting( 'weixinapp-group', 'timeguoqi' );
			  register_setting( 'weixinapp-group', 'gaodusetimp' );
			  register_setting( 'weixinapp-group', 'beishuset' );
			  register_setting( 'weixinapp-group', 'erciyuedu' );
	   register_setting( 'weixinapp-group', 'kongzhimessage' );
	
	
	
    register_setting( 'weixinapp-group', 'wf_paykey' );
    register_setting( 'weixinapp-group', 'wf_paybody' );

    register_setting( 'weixinapp-group', 'wf_poster_imageurl' );
    register_setting( 'weixinapp-group', 'wf_enable_comment_option' );
    register_setting( 'weixinapp-group', 'wf_enable_comment_check' );
    register_setting( 'weixinapp-group', 'wf_praise_word' );
    register_setting( 'weixinapp-group', 'wf_enterprise_minapp' );
	

    register_setting( 'weixinapp-group', 'wf_list_ad' );
    register_setting( 'weixinapp-group', 'wf_list_ad_id' );

    register_setting( 'weixinapp-group', 'wf_list_ad_every' );


    register_setting( 'weixinapp-group', 'wf_excitation_ad_id' );
    register_setting( 'weixinapp-group', 'wf_video_ad_id' );
    register_setting( 'weixinapp-group', 'wf_interstitial_ad_id' );
    
    

    

    register_setting( 'weixinapp-group', 'wf_detail_ad' );
    register_setting( 'weixinapp-group', 'wf_detail_ad_id' );
    register_setting( 'weixinapp-group', 'wf_about' );
    register_setting( 'weixinapp-group', 'wf_display_categories' );

    register_setting( 'weixinapp-group', 'wf_downloadfile_domain' );
    register_setting( 'weixinapp-group', 'wf_business_domain' );
    register_setting( 'weixinapp-group', 'wf_zan_imageurl' );
    register_setting( 'weixinapp-group', 'wf_logo_imageurl' );

    register_setting( 'weixinapp-group', 'enable_index_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_detail_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_topic_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_list_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_hot_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_comments_interstitial_ad' );
    register_setting( 'weixinapp-group', 'enable_live_interstitial_ad' );
    
    

    




    
    


    
    
    
   


    




    

    
    
       
    
    
}

function weixinapp_settings_page() {
?>
<div class="wrap">

<h2>设置</h2>


<p>微信公众号【鹿先森音乐馆】 <a href="https://www.emojy.cn" target="_blank">小白黑马资源网</a>.
<?php

if (!empty($_REQUEST['settings-updated']))
{
    echo '<div id="message" class="updated fade"><p><strong>设置已保存</strong></p></div>';

} 

if (version_compare(PHP_VERSION, '5.6.0', '<=') )
{
    
    echo '<div class="notice notice-error is-dismissible">
    <p><font color="red">提示：php版本小于5.6.0, 插件程序将无法正常使用,当前系统的php版本是:'.PHP_VERSION.'</font></p>
    </div>';

}
?>
<form method="post" action="options.php">
    <div class="responsive-tabs">
    <?php settings_fields( 'weixinapp-group' ); ?>
    <?php do_settings_sections( 'weixinapp-group' ); ?>
    <div class="responsive-tabs">
    <h2> 常规设置</h2>
    <div class="section">
        <table class="form-table">
            <tr valign="top">
            <th scope="row">AppID</th>
            <td><input type="text" name="wf_appid" style="width:400px; height:40px" value="<?php echo esc_attr( get_option('wf_appid') ); ?>" />* </td>
            </tr>
             
            <tr valign="top">
            <th scope="row">AppSecret</th>
            <td><input type="text" name="wf_secret" style="width:400px; height:40px" value="<?php echo esc_attr( get_option('wf_secret') ); ?>" />* </td>
            </tr>

                        
						
						
						
				
                   
        </table>
    </div>
    <h2>广告设置</h2>
    <div class="section">
    <table class="form-table">
   

        <tr valign="top">
        <th scope="row">Banner广告id</th>
            <td>

                <?php
                $wf_detail_ad =get_option('wf_detail_ad');            
                
                ?>
                <input type="text" name="wf_detail_ad_id" style="width:300px; height:40px" value="<?php echo esc_attr( get_option('wf_detail_ad_id') ); ?>" />
            </td>
        </tr>

        <tr valign="top">
                        <th scope="row">激励视频广告id</th>
                            <td>                                
                               <input type="text" name="wf_excitation_ad_id" style="width:300px; height:40px" value="<?php echo esc_attr( get_option('wf_excitation_ad_id') ); ?>" />
                            </td>
          </tr>
          <tr valign="top">
                        <th scope="row">视频广告id</th>
                            <td>                                
                               <input type="text" name="wf_video_ad_id" style="width:300px; height:40px" value="<?php echo esc_attr( get_option('wf_video_ad_id') ); ?>" />
                            </td>
          </tr>
          <tr valign="top">
          <th scope="row">插屏广告id</th>
                            <td>                                
                               <input type="text" name="wf_interstitial_ad_id" style="width:300px; height:40px" value="<?php echo esc_attr( get_option('wf_interstitial_ad_id') ); ?>" />
         </td>
         </tr>
         
</table>
    </div>


 </div>

    
    <?php submit_button();?>
</form>
 <?php get_jquery_source(); ?>
            <script>
               jQuery(document).ready(function($) {
                RESPONSIVEUI.responsiveTabs();
                // if($("input[name=post_meta]").attr('checked')) {
                //     $("#section_meta_list").addClass("hide");
                // }
            });
            </script>
</div>
<?php }  