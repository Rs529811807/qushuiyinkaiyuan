<?php
header('content-type:application/json;charset=utf8'); 
  echo json_encode(['code' => 1,'message'=>"1默认全部激励视频，0不是"]);
?>